from __future__ import print_function
from crhelper import CfnResource
from amazon_lex_bot_deploy import amazon_lex_bot_deploy
import json
import logging

logger = logging.getLogger(__name__)
# Initialise the helper, all inputs are optional, this example shows the defaults
helper = CfnResource(json_logging=False, log_level='DEBUG', boto_level='CRITICAL', sleep_on_delete=120)

try:
    ## Init code goes here
    pass
except Exception as e:
    helper.init_failure(e)


@helper.create
@helper.update
def create(event, context):
    logger.info('Beginning Lex Deployment')
    # Create the Lex bot
    try:
        amazon_lex_bot_deploy.lex_deploy(
            lex_schema_file='blog_chatbot_Export.json', lambda_endpoint=event['ResourceProperties']['ValidationLambdaArn'])
    except Exception as e:
        logger.error(e)
        raise e
    else:
        logger.info(f'Completed Lex Deployment')
        helper.Data['Status']= 'Completed'


@helper.delete
def delete(event, context):
    logger.info("Got Delete")
    # Delete never returns anything. Should not fail if the underlying resources are already deleted.
    # Desired state.

def lambda_handler(event, context):
    logger.info(json.dumps(event, indent=2))
    helper(event, context)
