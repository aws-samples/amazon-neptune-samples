import json
import boto3
import logging
from blog_parser import AwsBlogParser
from process_posts import ComprehendProcessor
from crhelper import CfnResource

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
helper = CfnResource(json_logging=False, log_level='DEBUG', boto_level='CRITICAL', sleep_on_delete=120)

@helper.create
@helper.update
def create(event, context):
    url=event['ResourceProperties']['URL']
    lambda_client = boto3.client('lambda')
    logger.info(f'Retrieving Blog Posts for {url}')
    results = AwsBlogParser(url).parse()
    logger.info('Creating Processor for Amazon Comprehend')
    comprehend = ComprehendProcessor()
    for r in results:
        logger.info(f'Processing post {r["title"]}')
        comprehend.process(r)
        response = lambda_client.invoke(
            FunctionName="chatbot-database-loader",
            InvocationType='Event',
            Payload=json.dumps(r)
        )
    helper.Data['Status']= 'Completed'


@helper.delete
def delete(event, context):
    logger.info("Got Delete")
    # Delete never returns anything. Should not fail if the underlying resources are already deleted.
    # Desired state.

def lambda_handler(event, context):
    logger.info(json.dumps(event, indent=2))
    helper(event, context)
